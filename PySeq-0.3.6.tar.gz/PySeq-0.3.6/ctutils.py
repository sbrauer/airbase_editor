# $Id: ctutils.py,v 1.6 2005-07-10 23:47:28+02 brinkman Exp $
# utilities for modules using ctypes, such as pyseq.py and pyrobot.py
# Copyright (c) 2005 Peter Brinkmann (brinkman@math.tu-berlin.de)

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation (http://www.gnu.org/copyleft/gpl.html).

import sys
import os

def findOnPath(lib):
    for p in sys.path:
        if p:
            fn='%s/%s' % (p, lib)
        else:
            fn='./%s' % lib
        if os.path.isfile(fn):
            return fn
    raise IOError, '%s not found on path' % lib
