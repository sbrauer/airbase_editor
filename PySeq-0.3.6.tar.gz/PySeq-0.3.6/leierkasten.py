#!/usr/bin/python

"""
$Id: leierkasten.py,v 1.4 2005-07-23 04:08:55+02 brinkman Exp $
A simple hand organ emulator
Peter Brinkmann (brinkman@math.tu-berlin.de)

Usage:
    python leierkasten.py foo.mid

This program will play a MIDI file. If you connect the input port of
leierkasten to the output port of a MIDI controller, then the rate of
change of incoming control change message will determine the tempo of
the MIDI player.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation (http://www.gnu.org/copyleft/gpl.html).
"""

import time
from pyseq import *

class SimpleKalman:     # some mathematical magic to smooth out MIDI input
    def __init__(self, p, q, r):
        self.p=p
        self.q=q
        self.r=r
        self.x=None
    def next(self, x):
        if self.x is None:
            self.x=x
            return x
        pm=self.p+self.q
        k=pm/(pm+self.r)
        self.x+=k*(x-self.x)
        self.p=(1-k)*pm
        return self.x


class Leierkasten(PySeq):
    def __init__(self, gain=2):
        PySeq.__init__(self, 'Leierkasten')     # create sequencer
        self.port=self.createInOutPort()        # create port for input, output
        self.tempo=SimpleKalman(1, 1e-5, .03)
        self.e=snd_seq_event()                  # this is the event we'll send
        self.e.type=SND_SEQ_EVENT_TEMPO         # over and over again
        self.e.setSubscribers()
        self.ch=self.ctrl=self.v0=self.t0=None
        self.gain=gain                 # gain: quarters notes per revolution
    def callback(self, ev):
        if ev.type==SND_SEQ_EVENT_CONTROLLER:  # incoming control change event?
            t1=time.time()
            dat=ev.getData()
            ch, ctrl, v1=dat.channel, dat.param, dat.value
            if self.ch==None:
                self.t0=t1
                self.v0=v1
                self.ctrl=ctrl      # remember controller
                self.ch=ch
                return 1
            elif ch==self.ch and ctrl==self.ctrl: # same controller as before?
                dt=t1-self.t0       # time elapsed
                dv=v1-self.v0       # change of controller value
                if dv!=0 and dt>0:
                    self.t0=t1
                    self.v0=v1
                    self.e.getData().param.value=int(self.tempo.next(
                                            128*dt*1e6/abs(dv)/self.gain))
                                    # compute new rate of change
                    self.e.sendNow(self, self.port) # send event to subscribers
        return 1
            

if __name__=='__main__':
    MidiThread(Leierkasten()).start()
    raw_input('connect ports, hit return')

