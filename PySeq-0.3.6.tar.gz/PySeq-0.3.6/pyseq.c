/* $Id: pyseq.c,v 1.54 2005-08-09 15:37:14+02 brinkman Exp $
 * Peter Brinkmann (brinkman@math.tu-berlin.de)
 * loosely based on midiroute.c as well as miniArp.c by Matthias Nagorni
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation (http://www.gnu.org/copyleft/gpl.html).
 */

#include <string.h>
#include <stdio.h>
#include <poll.h>
#include <unistd.h>
#include <sys/types.h>
#include <alsa/asoundlib.h>

snd_seq_t *openSeq(char *clientname) {
  snd_seq_t *seq_handle;
  if (snd_seq_open(&seq_handle, "default", SND_SEQ_OPEN_DUPLEX, 0) < 0) {
      return NULL;
  }
  snd_seq_set_client_name(seq_handle,clientname);
  return seq_handle;
}

int clientID(snd_seq_t *seq_handle) {
    return snd_seq_client_id(seq_handle);
}

int syncSeq(snd_seq_t *seq_handle) {
    return snd_seq_sync_output_queue(seq_handle);
}

int setInputPool(snd_seq_t *seq_handle, int size) {
    return snd_seq_set_client_pool_input(seq_handle, size);
}

int setOutputPool(snd_seq_t *seq_handle, int size) {
    return snd_seq_set_client_pool_output(seq_handle, size);
}

int setOutputPoolRoom(snd_seq_t *seq_handle, int size) {
    return snd_seq_set_client_pool_output_room(seq_handle, size);
}

int createInPort(snd_seq_t *seq_handle, char *portname, int allowSubs) {
    return snd_seq_create_simple_port(seq_handle, portname,
        SND_SEQ_PORT_CAP_WRITE| (SND_SEQ_PORT_CAP_SUBS_WRITE*allowSubs)
        /*|SND_SEQ_PORT_CAP_SYNC_WRITE*/,
        SND_SEQ_PORT_TYPE_APPLICATION|SND_SEQ_PORT_TYPE_MIDI_GENERIC);
}

int createOutPort(snd_seq_t *seq_handle, char *portname, int allowSubs) {
    return snd_seq_create_simple_port(seq_handle, portname,
          SND_SEQ_PORT_CAP_READ|(SND_SEQ_PORT_CAP_SUBS_READ*allowSubs)
          /*|SND_SEQ_PORT_CAP_SYNC_READ*/,
          SND_SEQ_PORT_TYPE_APPLICATION|SND_SEQ_PORT_TYPE_MIDI_GENERIC);
}

int createInOutPort(snd_seq_t *seq_handle, char *portname,
                 int allowReadSubs, int allowWriteSubs) {
    return snd_seq_create_simple_port(seq_handle, portname,
          SND_SEQ_PORT_CAP_WRITE|(SND_SEQ_PORT_CAP_SUBS_WRITE*allowWriteSubs)|
          /*SND_SEQ_PORT_CAP_SYNC_WRITE|*/
          SND_SEQ_PORT_CAP_READ|(SND_SEQ_PORT_CAP_SUBS_READ*allowReadSubs)|
          /*SND_SEQ_PORT_CAP_SYNC_READ|*/
          SND_SEQ_PORT_CAP_DUPLEX,
          SND_SEQ_PORT_TYPE_APPLICATION|SND_SEQ_PORT_TYPE_MIDI_GENERIC);
}

int deletePort(snd_seq_t *seq_handle, int port) {
    snd_seq_delete_simple_port(seq_handle, port);
}

int connectFrom(snd_seq_t *seq, int my_port, int src_client, int src_port) {
    return snd_seq_connect_from(seq, my_port, src_client, src_port);
}

int connectTo(snd_seq_t *seq, int my_port, int dest_client, int dest_port) {
    return snd_seq_connect_to(seq, my_port, dest_client, dest_port);
}

int disconnectFrom(snd_seq_t *seq, int my_port, int src_client, int src_port) {
    return snd_seq_disconnect_from(seq, my_port, src_client, src_port);
}

int disconnectTo(snd_seq_t *seq, int my_port, int dest_client, int dest_port) {
    return snd_seq_disconnect_to(seq, my_port, dest_client, dest_port);
}

int midiLoop(snd_seq_t *seq_handle,
        int callback(snd_seq_event_t *),
        int *stopped) {
  snd_seq_event_t *ev;
  struct pollfd *pfd=NULL;
  int npfd;
  int res;
  npfd = snd_seq_poll_descriptors_count(seq_handle, POLLIN);
  pfd = (struct pollfd *)alloca(npfd * sizeof(struct pollfd));
  snd_seq_poll_descriptors(seq_handle, pfd, npfd, POLLIN);
  while (!(*stopped)) {
    if (poll(pfd, npfd, 100) > 0) {
      do {
        snd_seq_event_input(seq_handle, &ev);
        res=callback(ev);
        if (res & 1) snd_seq_free_event(ev);
        if (res & 2) *stopped=1;
      } while ((snd_seq_event_input_pending(seq_handle, 0) > 0)
                    && !(*stopped));
    }  
  }
  return 0;
}

void clearEvent(snd_seq_event_t *ev) {
    snd_seq_ev_clear(ev);
}

void setPriority(snd_seq_event_t *ev, int hp) {
    snd_seq_ev_set_priority(ev, hp);
}

void setNote(snd_seq_event_t *ev, int ch, int key, int vel, int dur) {
    snd_seq_ev_set_note(ev, ch, key, vel, dur);
}

void setNoteOn(snd_seq_event_t *ev, int ch, int key, int vel) {
    snd_seq_ev_set_noteon(ev, ch, key, vel);
}

void setNoteOff(snd_seq_event_t *ev, int ch, int key, int vel) {
    snd_seq_ev_set_noteoff(ev, ch, key, vel);
}

void setKeypress(snd_seq_event_t *ev, int ch, int key, int vel) {
    snd_seq_ev_set_keypress(ev, ch, key, vel);
}

void setController(snd_seq_event_t *ev, int ch, int cc, int val) {
    snd_seq_ev_set_controller(ev, ch, cc, val);
}

void setPgmchange(snd_seq_event_t *ev, int ch, int val) {
    snd_seq_ev_set_pgmchange(ev, ch, val);
}

void setPitchbend(snd_seq_event_t *ev, int ch, int val) {
    snd_seq_ev_set_pitchbend(ev, ch, val);
}

void setChanpress(snd_seq_event_t *ev, int ch, int val) {
    snd_seq_ev_set_chanpress(ev, ch, val);
}

void setSysex(snd_seq_event_t *ev, int len, void *ptr) {
    snd_seq_ev_set_sysex(ev, len, ptr);
}

void setSource(snd_seq_event_t *ev, int srcport) {
    snd_seq_ev_set_source(ev, srcport);
}

void setBroadcast(snd_seq_event_t *ev) {
    snd_seq_ev_set_broadcast(ev);
}

void setSubscribers(snd_seq_event_t *ev) {
    snd_seq_ev_set_subs(ev);
}

void setDestination(snd_seq_event_t *ev, int destclient, int destport) {
    snd_seq_ev_set_dest(ev, destclient, destport);
}

void scheduleTick(snd_seq_event_t *ev, int queue_id, int rel, int tick) {
    snd_seq_ev_schedule_tick(ev, queue_id,  rel, tick);
}

void scheduleRealTime(snd_seq_event_t *ev, int queue_id, int rel,
        snd_seq_real_time_t *time) {
    snd_seq_ev_schedule_real(ev, queue_id,  rel, time);
}

void setDirect(snd_seq_event_t *ev) {
    snd_seq_ev_set_direct(ev);
}

int sendAsIs(snd_seq_event_t *ev, snd_seq_t *seq_handle) {
    if (snd_seq_event_output_direct(seq_handle, ev) < 0) return -1;
    return 0;
}

int setQueueStart(snd_seq_event_t *ev, int queue_id) {
    snd_seq_ev_set_queue_start(ev, queue_id);
}

int setQueueStop(snd_seq_event_t *ev, int queue_id) {
    snd_seq_ev_set_queue_stop(ev, queue_id);
}

int setQueueContinue(snd_seq_event_t *ev, int queue_id) {
    snd_seq_ev_set_queue_continue(ev, queue_id);
}

int setQueueTempo(snd_seq_event_t *ev, int queue_id, int tempo) {
    snd_seq_ev_set_queue_tempo(ev, queue_id, tempo);
}

int setQueuePosRealTime(snd_seq_event_t *ev, int queue_id,
                snd_seq_real_time_t *time) {
    snd_seq_ev_set_queue_pos_real(ev, queue_id, time);
}

int setQueuePosTick(snd_seq_event_t *ev, int queue_id, int tick) {
    snd_seq_ev_set_queue_pos_tick(ev, queue_id, tick);
}

int createQueue(snd_seq_t *seq_handle, char *name) {
    return snd_seq_alloc_named_queue(seq_handle, name);
}

void deleteQueue(snd_seq_t *seq_handle, int queue_id) {
    snd_seq_free_queue(seq_handle, queue_id);
}

void setTempo(snd_seq_t *seq_handle, int queue_id, int mtv, int tpq) {
    snd_seq_queue_tempo_t *queue_tempo;
    snd_seq_queue_tempo_malloc(&queue_tempo);
    snd_seq_queue_tempo_set_tempo(queue_tempo, mtv);
    snd_seq_queue_tempo_set_ppq(queue_tempo, tpq);
    snd_seq_set_queue_tempo(seq_handle, queue_id, queue_tempo);
    snd_seq_queue_tempo_free(queue_tempo);
}

unsigned int getTempo(snd_seq_t *seq_handle, int queue_id) {
    snd_seq_queue_tempo_t *queue_tempo;
    snd_seq_queue_tempo_malloc(&queue_tempo);
    snd_seq_get_queue_tempo(seq_handle, queue_id, queue_tempo);
    unsigned int tempo=snd_seq_queue_tempo_get_tempo(queue_tempo);
    snd_seq_queue_tempo_free(queue_tempo);
    return tempo;
}

void startQueue(snd_seq_t *seq_handle, int queue_id) {
    snd_seq_start_queue(seq_handle, queue_id, NULL);
    snd_seq_drain_output(seq_handle);
}

void stopQueue(snd_seq_t *seq_handle, int queue_id) {
    snd_seq_stop_queue(seq_handle, queue_id, NULL);
    snd_seq_drain_output(seq_handle);
}

void continueQueue(snd_seq_t *seq_handle, int queue_id) {
    snd_seq_continue_queue(seq_handle, queue_id, NULL);
    snd_seq_drain_output(seq_handle);
}

void clearQueue(snd_seq_t *seq_handle, int queue_id) {
    snd_seq_remove_events_t *remove_ev;
    snd_seq_remove_events_malloc(&remove_ev);
    snd_seq_remove_events_set_queue(remove_ev, queue_id);
    snd_seq_remove_events_set_condition(remove_ev, SND_SEQ_REMOVE_OUTPUT);
    snd_seq_remove_events(seq_handle, remove_ev);
    snd_seq_remove_events_free(remove_ev);
}

unsigned int getTick(snd_seq_t *seq_handle, int queue_id) {
    snd_seq_queue_status_t *status;
    snd_seq_queue_status_malloc(&status);
    snd_seq_get_queue_status(seq_handle, queue_id, status);
    unsigned int current_tick =
            (unsigned int) snd_seq_queue_status_get_tick_time(status);
    snd_seq_queue_status_free(status);
    return current_tick;
}

const snd_seq_real_time_t *getTime(snd_seq_t *seq_handle, int queue_id) {
    snd_seq_queue_status_t *status;
    snd_seq_queue_status_malloc(&status);
    snd_seq_get_queue_status(seq_handle, queue_id, status);
    const snd_seq_real_time_t *current_time=
             snd_seq_queue_status_get_real_time(status);
    snd_seq_queue_status_free(status);
    return current_time;
}

int getEvents(snd_seq_t *seq_handle, int queue_id) {
    snd_seq_queue_status_t *status;
    snd_seq_queue_status_malloc(&status);
    snd_seq_get_queue_status(seq_handle, queue_id, status);
    int events = snd_seq_queue_status_get_events(status);
    snd_seq_queue_status_free(status);
    return events;
}

int getStatus(snd_seq_t *seq_handle, int queue_id) {
    snd_seq_queue_status_t *status;
    snd_seq_queue_status_malloc(&status);
    snd_seq_get_queue_status(seq_handle, queue_id, status);
    int stat = snd_seq_queue_status_get_status(status);
    snd_seq_queue_status_free(status);
    return stat;
}

typedef struct midiport {
    int client;
    int port;
    int caps;
    char name[32];
} midiport;

typedef struct midiclient {
    int id;
    char name[32];
} midiclient;

typedef struct midiconnect {
    int srcclient;
    int srcport;
    int destclient;
    int destport;
} midiconnect;

typedef struct seqlist {
    int nclients;
    midiclient clients[64];
    int nports;
    midiport ports[256];
    int nconnect;
    midiconnect connect[1024];
} seqlist;

int getClients(seqlist *sl) {
    snd_seq_client_info_t *cinfo;
    snd_seq_port_info_t *pinfo;
    snd_seq_query_subscribe_t *subs;
    snd_seq_t *handle;
    int err, client, port;
    int i=0;
    int j=0;
    int k=0;
    int ret=0;

    err=snd_seq_open(&handle, "hw", SND_SEQ_OPEN_DUPLEX, 0);
    if (err<0) return -1;

    snd_seq_client_info_alloca(&cinfo);
    snd_seq_port_info_alloca(&pinfo);
    snd_seq_query_subscribe_alloca(&subs);

    snd_seq_client_info_set_client(cinfo, -1);
    for(; snd_seq_query_next_client(handle, cinfo)>=0; i++) {
        if (i>=64) {
            ret=-2; // too many clients
            break;
        }
        sl->clients[i].id=client=snd_seq_client_info_get_client(cinfo);
        strncpy(sl->clients[i].name, snd_seq_client_info_get_name(cinfo), 31);
        sl->clients[i].name[31]=0;

        snd_seq_port_info_set_client(pinfo, client);
        snd_seq_port_info_set_port(pinfo, -1);
        for(; snd_seq_query_next_port(handle, pinfo)>=0; j++) {
            if (j>=256) {
                ret=-3; // too many ports
                break;
            }
            sl->ports[j].client=client;
            sl->ports[j].port=port=snd_seq_port_info_get_port(pinfo);
            sl->ports[j].caps=snd_seq_port_info_get_capability(pinfo);
            strncpy(sl->ports[j].name, snd_seq_port_info_get_name(pinfo), 31);
            sl->ports[j].name[31]=0;

            snd_seq_query_subscribe_set_root(subs,
                         snd_seq_port_info_get_addr(pinfo));
            snd_seq_query_subscribe_set_type(subs, SND_SEQ_QUERY_SUBS_READ);
            snd_seq_query_subscribe_set_index(subs, 0);
            for(; snd_seq_query_port_subscribers(handle, subs)>=0; k++) {
                if (k>=1024) {
                    ret=-4; // too many connections
                    break;
                }
                const snd_seq_addr_t *addr=
                                snd_seq_query_subscribe_get_addr(subs);
                sl->connect[k].srcclient=client;
                sl->connect[k].srcport=port;
                sl->connect[k].destclient=addr->client;
                sl->connect[k].destport=addr->port;

                snd_seq_query_subscribe_set_index(subs,
                         snd_seq_query_subscribe_get_index(subs) + 1);
            }
        }
    }
    sl->nclients=i;
    sl->nports=j;
    sl->nconnect=k;
    snd_seq_close(handle);
    return ret;
}

