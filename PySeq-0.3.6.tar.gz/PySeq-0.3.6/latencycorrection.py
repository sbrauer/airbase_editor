#!/usr/bin/python

"""
$Id: latencycorrection.py,v 1.7 2005-08-10 17:37:42+02 brinkman Exp $
Basic latency correction for ALSA
Copyright (c) 2005 Peter Brinkmann (brinkman@math.tu-berlin.de)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation (http://www.gnu.org/copyleft/gpl.html).
"""


from pyseq import *

class LatencyCorrection(PySeq):
    def __init__(self, name='LatencyCorrection'):
        PySeq.__init__(self, name)
        self.setOutputPool(1024)
        self.q=Queue(self)
        self.q.start()
        self.mt=MidiThread(self)
        self.mt.start()
        self.latencies={}
        self.maxLatency=0
    def addPort(self, latency=.0, allowWriteSubs=1):
        """adds a port intended to be attached to an output device of
        the given latency, measured in milliseconds"""
        lat=int(latency*1e6+.5)
        port=self.createInOutPort('latency %.1f' % latency,
                                allowWriteSubs=allowWriteSubs)
        self.latencies[port]=lat
        self.maxLatency=max(lat, self.maxLatency) # atomic; no locking
        return port
    def deletePort(self, port):
        """removes given port, adjusts latency correction accordingly"""
        self.panic(port)
        PySeq.deletePort(self, port)
        del self.latencies[port]
        self.maxLatency=max(self.latencies.values())
    def callback(self, ev):
        pt=ev.dest.port
        lat=self.maxLatency-self.latencies[pt]
        ev.postToQueueRealTime(self.q, pt, lat/10**9, lat%10**9, 1)
        return 1


def lcMain():
    import sys
    import time
    def usage():
        sys.stderr.write('usage: %s [latency1 [latency2 ...]]\n' % sys.argv[0])
        sys.exit(1)
    lt=LatencyCorrection()
    if len(sys.argv)>1:
        try:
            for lat in sys.argv[1:]:
                lt.addPort(float(lat))
        except: usage()
    else:
        lt.addPort()
    while 1: time.sleep(1)


if __name__=='__main__':
    lcMain()
