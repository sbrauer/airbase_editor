#!/usr/bin/python

# $Id: setup.py,v 1.9 2005-08-17 04:14:38+02 brinkman Exp brinkman $
# PySeq installation script
# Copyright (c) 2005 Peter Brinkmann (brinkman@math.tu-berlin.de)

from distutils.core import setup, Extension

setup(
    name='PySeq',
    version='0.3.6',
    description='PySeq and PyRobot --- Python bindings for ALSA and X',
    author='Peter Brinkmann',
    author_email='brinkman@math.tu-berlin.de',
    license='GNU General Public License',
    url='http://www.math.tu-berlin.de/~brinkman/software/pyseq/',
    py_modules=['ctutils', 'pyrobot', 'pyseq', 'latencycorrection'],
    scripts=['scripts/midisync'],
    ext_modules=[
        Extension('_pyseq', ['pyseq.c'],
            libraries=['asound'],
            extra_compile_args=['-pthread', '-shared', '-fPIC']
        ),
        Extension('_pyrobot', ['pyrobot.c'],
            library_dirs=['/usr/X11R6/lib'],
            libraries=['X11', 'Xtst'],
            extra_compile_args=['-pthread', '-shared', '-fPIC']
        )
    ]
)
