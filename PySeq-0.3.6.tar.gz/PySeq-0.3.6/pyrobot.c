/* $Id: pyrobot.c,v 1.8 2005-07-10 23:47:28+02 brinkman Exp $
 * Peter Brinkmann (brinkman@math.tu-berlin.de)
 * very loosely based on xmacrorec and xmacroplay
 * (see http://xmacro.sourceforge.net/)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation (http://www.gnu.org/copyleft/gpl.html).
 */

#include <X11/Xlibint.h>
#include <X11/extensions/XTest.h>

Display *openDisplay() {
    return XOpenDisplay(0);
}

int closeDisplay(Display *dsp) {
    return XCloseDisplay(dsp);
}

int grabMouse(Display *dsp) {
    Window root=RootWindow(dsp, DefaultScreen(dsp));
    if (XGrabPointer ( dsp, root, False,
        PointerMotionMask|ButtonPressMask|ButtonReleaseMask,
        GrabModeSync, GrabModeAsync, root, None, CurrentTime )!=GrabSuccess) {
        return 1;
    }
    return 0;
}

int grabKeyboard(Display *dsp) {
    Window root=RootWindow(dsp, DefaultScreen(dsp));
    if (XGrabKeyboard ( dsp, root, False, GrabModeSync,
        GrabModeAsync, CurrentTime ) != GrabSuccess) {
        return 1;
    }
    return 0;
}

int releaseMouse(Display *dsp) {
    XUngrabPointer( dsp, CurrentTime );
    return 0;
}

int releaseKeyboard(Display *dsp) {
    XUngrabKeyboard( dsp, CurrentTime );
    return 0;
}

int getXEvent(Display *dsp, XEvent *ev) {
    Window root=RootWindow(dsp, DefaultScreen(dsp));
    XAllowEvents ( dsp, SyncPointer, CurrentTime);
    XWindowEvent ( dsp, root,
                   KeyPressMask|KeyReleaseMask|PointerMotionMask
                   |ButtonPressMask|ButtonReleaseMask, ev);
    return 0;
}
