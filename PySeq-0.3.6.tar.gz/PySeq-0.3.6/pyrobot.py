"""
$Id: pyrobot.py,v 1.24 2005-07-25 20:30:35+02 brinkman Exp $
Copyright (c) 2005 Peter Brinkmann (brinkman@math.tu-berlin.de)

a rough approximation of java.awt.Robot using XTest, consisting mostly
of ctypes wrappers for the XEvent union, plus an abstraction layer that
hides the details of X and XTest library calls

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation (http://www.gnu.org/copyleft/gpl.html).
"""

from ctypes import *
import ctutils
import time

KeyPress=2
KeyRelease=3
ButtonPress=4
ButtonRelease=5
MotionNotify=6

class XKeyEvent(Structure):
    _fields_=[
        ('type', c_int),
        ('serial', c_ulong),
        ('send_event', c_int),
        ('display', c_void_p),
        ('window', c_ulong),
        ('root', c_ulong),
        ('subwindow', c_ulong),
        ('time', c_ulong),
        ('x', c_int),
        ('y', c_int),
        ('x_root', c_int),
        ('y_root', c_int),
        ('state', c_uint),
        ('keycode', c_uint),
        ('same_screen', c_int)
    ]
    def __repr__(self):
        return 'KeyEvent (type %d, x %d, y %d, keycode %d)' % \
                (self.type, self.x, self.y, self.keycode)

class XButtonEvent(Structure):
    _fields_=[
        ('type', c_int),
        ('serial', c_ulong),
        ('send_event', c_int),
        ('display', c_void_p),
        ('window', c_ulong),
        ('root', c_ulong),
        ('subwindow', c_ulong),
        ('time', c_ulong),
        ('x', c_int),
        ('y', c_int),
        ('x_root', c_int),
        ('y_root', c_int),
        ('state', c_uint),
        ('button', c_uint),
        ('same_screen', c_int)
    ]
    def __repr__(self):
        return 'ButtonEvent (type %d, x %d, y %d, button %d)' % \
                (self.type, self.x, self.y, self.button)


class XMotionEvent(Structure):
    _fields_=[
        ('type', c_int),
        ('serial', c_ulong),
        ('send_event', c_int),
        ('display', c_void_p),
        ('window', c_ulong),
        ('root', c_ulong),
        ('subwindow', c_ulong),
        ('time', c_ulong),
        ('x', c_int),
        ('y', c_int),
        ('x_root', c_int),
        ('y_root', c_int),
        ('state', c_uint),
        ('is_hint', c_byte),
        ('same_screen', c_int)
    ]
    def __repr__(self):
        return 'MotionEvent (type %d, x %d, y %d, is_hint %d)' % \
                (self.type, self.x, self.y, self.is_hint)


class XEvent(Union):
    _fields_=[
        ('type', c_int),
        ('xkey', XKeyEvent),
        ('xbutton', XButtonEvent),
        ('xmotion', XMotionEvent),
        ('pad', c_long*24)
    ]
    def getData(self):
        if self.type in [KeyPress, KeyRelease]:
            return self.xkey
        elif self.type in [ButtonPress, ButtonRelease]:
            return self.xbutton
        elif self.type in [MotionNotify]:
            return self.xmotion
        else:
            raise RuntimeError, 'Unhandled XEvent type'
    def __repr__(self):
        return 'XEvent: %s' % `self.getData()`


libpyrobot=cdll.LoadLibrary(ctutils.findOnPath('_pyrobot.so'))
class PyRobot:
    """a rough approximation of java.awt.Robot"""
    __xd=None   # a singleton for keeping the handle of an X display
    def __init__(self):
        if not PyRobot.__xd:
            PyRobot.__xd=libpyrobot.openDisplay()
    def check(self):
        assert PyRobot.__xd is not None, 'Display already closed'
    def close(self):
        """close X display; do not use PyRobot after calling this function"""
        self.check()
        libpyrobot.closeDisplay(PyRobot.__xd)
        PyRobot.__xd=None
    def flush(self):
        """flush X event queue"""
        self.check()
        libpyrobot.XFlush(PyRobot.__xd)
    def grabMouse(self):
        """grab mouse focus; make sure to call releaseMouse when done"""
        self.check()
        libpyrobot.grabMouse(PyRobot.__xd)
    def grabKeyboard(self):
        """grab keyboard focus; make sure to call releaseKeyboard when done"""
        self.check()
        libpyrobot.grabKeyboard(PyRobot.__xd)
    def releaseMouse(self):
        self.check()
        libpyrobot.releaseMouse(PyRobot.__xd)
        self.flush()
    def releaseKeyboard(self):
        self.check()
        libpyrobot.releaseKeyboard(PyRobot.__xd)
        self.flush()
    def grabAll(self):
        """grad both mouse and keyboard focus; make sure to call releaseAll
        when done"""
        self.check()
        self.grabMouse()
        self.grabKeyboard()
    def releaseAll(self):
        self.check()
        self.releaseMouse()
        self.releaseKeyboard()
    def getEvent(self):
        """wait for and return the next X event"""
        self.check()
        ev=XEvent()
        libpyrobot.getXEvent(PyRobot.__xd, addressof(ev))
        return ev
    def sendKeyEvent(self, kc, isp):
        """send key event with keycode kc; isp is a flag indicating
        whether the key is to be pressed or released"""
        self.check()
        libpyrobot.XTestFakeKeyEvent(PyRobot.__xd, kc, isp, 0)
        self.flush()
    def sendButtonEvent(self, bt, isp):
        """send mouse button event on button bt; isp is a flag indicating
        whether the button is to be pressed or released"""
        self.check()
        libpyrobot.XTestFakeButtonEvent(PyRobot.__xd, bt, isp, 0)
        self.flush()
    def sendMotionEvent(self, x, y):
        """send mouse motion event to coordinates (x, y)"""
        self.check()
        libpyrobot.XTestFakeMotionEvent(PyRobot.__xd, -1, x, y, 0)
        self.flush()
    def pickPoint(self):
        """grab console, then wait for button press and return the coordinates
        and button number of the event"""
        self.grabMouse()
        res=None
        try:
            while 1:
                ev=self.getEvent()
                if ev.type==ButtonPress:
                    dat=ev.getData()
                    res=(dat.x, dat.y, dat.button)
                    break
        finally:
            self.releaseMouse()
        return res
    def pickKey(self):
        """grab console, then wait for key press and return coordinates and
        keycode of the event"""
        self.grabAll()
        res=None
        try:
            while 1:
                ev=self.getEvent()
                if ev.type==KeyPress:
                    dat=ev.getData()
                    res=(dat.x, dat.y, dat.keycode)
                    break
        finally:
            self.releaseAll()
        return res


class Script:
    """records and replays sequences of X events"""
    def __init__(self):
        self.sequence=[]
    def record(self, rob, quitcode=9L):
        """record a sequence of X events; rob is an instance of PyRobot;
        the default quitcode of 9L corresponds to the Escape key"""
        self.sequence=[]
        dragstate=0
        t0=None
        rob.grabAll()
        try:
            while 1:
                ev=rob.getEvent()
                dat=ev.getData()
                if not t0:
                    dt=0
                else:
                    dt=time.time()-t0
                if ev.type==KeyPress or ev.type==KeyRelease:
                    if ev.type==KeyPress and dat.keycode==quitcode:
                        break
                    self.sequence.append((ev.type, dt, dat.keycode))
                elif ev.type==ButtonPress or ev.type==ButtonRelease:
                    if not dragstate:
                        self.sequence.append((MotionNotify, dt, dat.x, dat.y))
                        dt=0.05   # eyeball estimate...
                    self.sequence.append((ev.type, dt, dat.button))
                    dragstate^=2<<dat.button
                elif ev.type==MotionNotify and dragstate:
                    self.sequence.append((MotionNotify, dt, dat.x, dat.y))
                if self.sequence:
                    t0=time.time()
        finally:
            rob.releaseAll()
    def shift(self, dx=0, dy=0):
        """shift all mouse motion events in sequence by (dx, dy)"""
        for i in range(len(self.sequence)):
            s=self.sequence[i]
            if s[0]==MotionNotify:
                self.sequence[i]=(s[0], s[1], s[2]+dx, s[3]+dy)
    def getData(self, x0=0, y0=0):
        """return sequence of events, coordinates relative to (x0, y0)"""
        self.shift(-x0, -y0)
        res=self.sequence[:]
        self.shift(x0, y0)
        return res
    def setData(self, seq, x0=0, y0=0):
        """set sequence of events, coordinates relative to (x0, y0)"""
        self.sequence=seq[:]
        self.shift(x0, y0)
    def play(self, rob, delay=None):
        """replay sequence of X events; rob is an instance of PyRobot;
        if delay=None, then the delay between two X events is the delay
        recorded in the sequence"""
        for ev in self.sequence:
            tp=ev[0]
            if delay is None:
                time.sleep(ev[1])
            else:
                time.sleep(delay)
            if tp==KeyPress:
                rob.sendKeyEvent(ev[2], 1)
            elif tp==KeyRelease:
                rob.sendKeyEvent(ev[2], 0)
            elif tp==ButtonPress:
                rob.sendButtonEvent(ev[2], 1)
            elif tp==ButtonRelease:
                rob.sendButtonEvent(ev[2], 0)
            elif tp==MotionNotify:
                rob.sendMotionEvent(ev[2], ev[3])

if __name__=='__main__':
    D=PyRobot()
    S=Script()
    print 'record script, press Escape'
    S.record(D)
    raw_input('press return to replay script')
    S.play(D)
