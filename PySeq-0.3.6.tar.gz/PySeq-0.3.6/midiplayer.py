#!/usr/bin/python

"""
$Id: midiplayer.py,v 1.34 2005-08-08 16:37:01+02 brinkman Exp $
Simple MIDI file player
Peter Brinkmann (brinkman@math.tu-berlin.de)

A simple MIDI file player based on pyseq and the Python MIDI Package,
intended to serve as a tutorial for pyseq, the Python bindings for the
ALSA sequencer API.

A couple of features:
    - The MIDI player creates one output port per track, so that one can
    play different tracks with different instruments.
    - If MIDI tempo events get sent to the input port of the player, then
    the tempo will be changed accordingly. For instance, if you connect
    leierkasten.py to the input port, then the result will be a virtual
    hand organ.

The MIDI player consists of two parts:

MidiToAlsa
    A subclass of the MidiOutStream class of the Python MIDI package.
    The exact details of this class don't really matter here; the main
    point is that is uses some of the convenience methods of pyseq to
    create a list of tracks, where each track is a list of objects of
    type snd_seq_event (see pyseq.py)

PlaySeq
    A subclass that takes the list of tracks created by MidiToAlsa
    and plays them via queues. This class illustrates a number of
    techniques: Scheduling events, breaking a long song down into
    manageable chunks, etc.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation (http://www.gnu.org/copyleft/gpl.html).
"""

from MidiOutStream import MidiOutStream
from MidiInFile import MidiInFile
from pyseq import *
import sys
import time


class MidiToAlsa(MidiOutStream):
    def __init__(self, filename):
        self.copyright=None
        self.timesig=None
        self.keysig=None
        self.format=0
        self.tpq=96
        self.tracks=[]
        f=open(filename, 'rb')
        MidiInFile(self, f).read()
        f.close()
    def header(self, format=0, nTracks=1, division=96):
        self.tpq=division
        self.format=format
    def eof(self):
        pass
    def start_of_track(self, n_track=0):
        self.currentNumber=n_track
        self.currentName='track %d' % n_track
        self.current=[]     # accumulates the events of the current track
    def end_of_track(self):
        self.tracks.append((self.currentName, self.current))
    def newEvent(self):
        ev=snd_seq_event()
        ev.time.tick=self.abs_time()    # remember time in appropriate field
        self.current.append(ev)
        return ev
    def channel_message(self, message_type, channel, data):
        self.newEvent().setController(channel, controller, value)
    def note_on(self, channel=0, note=0x40, velocity=0x40):
        self.newEvent().setNoteOn(channel, note, velocity)
    def note_off(self, channel=0, note=0x40, velocity=0x40):
        self.newEvent().setNoteOff(channel, note, velocity)
    def aftertouch(self, channel=0, note=0x40, velocity=0x40):
        self.newEvent().setKeyPress(channel, note, velocity)
    def continuous_controller(self, channel, controller, value):
        self.newEvent().setController(channel, controller, value)
    def patch_change(self, channel, patch):
        self.newEvent().setPgmChange(channel, patch)
    def channel_pressure(self, channel, pressure):
        self.newEvent().setChanPress(channel, pressure)
    def pitch_bend(self, channel, value):
        self.newEvent().setPitchBend(channel, value)
    def system_exclusive(self, data):   # two handlers for sysex...
        self.newEvent().setSysEx(channel, [ord(c) for c in data])
    def sysex_event(self, data):        # not sure which one's needed...
        self.newEvent().setSysEx(channel, [ord(c) for c in data])
    def song_position_pointer(self, value):
        print 'song position ignored'
    def song_select(self, songNumber):
        print 'song select ignored'
    def tuning_request(self):
        print 'tuning request ignored'
    def midi_time_code(self, msg_type, values):
        print 'time code ignored'
    def meta_event(self, meta_type, data):
        print 'meta event ignored: %s' % `(meta_type, data)`
    def sequence_number(self, value):
        print 'sequence number ignored: %s' % `value`
    def text(self, text):
        print 'text ignored: %s' % text
    def copyright(self, text):
        self.copyright=text
    def sequence_name(self, text):
        print 'sequence name ignored: %s' % text
    def instrument_name(self, text):
        print 'instrument name ignored: %s' % text
    def lyric(self, text):
        print 'lyric ignored: %s' % text
    def marker(self, text):
        print 'marker ignored: %s' % text
    def cuepoint(self, text):
        print 'cuepoint ignored: %s' % text
    def midi_ch_prefix(self, channel):
        print 'midi ch prefix ignored: %s' % `channel`
    def midi_port(self, value):
        print 'midi port ignored: %s' % `value`
    def tempo(self, value):
        ev=self.newEvent()
        ev.type=SND_SEQ_EVENT_TEMPO
        ev.getData().param.value=value
        self.current.append(ev)
    def smtp_offset(self, hour, minute, second, frame, framePart):
        print 'smtp offset ignored: %s' % `(hour, minute, second,
                                           frame, framePart)`
    def time_signature(self, nn, dd, cc, bb):
        self.timesig=(nn, dd, cc, bb)
    def key_signature(self, sf, mi):
        self.keysig=(sf, mi)
    def sequencer_specific(self, data):
        self.seqspec=data
    def __repr__(self):
        return 'tpq: %s, tracks: %s' % `(self.tpq, self.tracks)`


class PlaySeq(PySeq):
    def __init__(self, tune, chunksize=256):
        PySeq.__init__(self, 'MidiPlayer')
        self.oports=[self.createOutPort(t[0]) for t in tune.tracks]
                # one port per track
        self.iport=self.createInPort('')
        self.chunksize=chunksize
        self.setOutputPool(2*self.chunksize+64)
                # make sure there's enough room for events in our queue
        self.q=Queue(self)
                # create queue
        self.q.setTempo(120, tune.tpq)
                # set queue tempo (bpm) and resolution (ticks per quarter note)
        self.events=[]  # flat list (all tracks together) of MIDI events
        for i in range(len(tune.tracks)):   # iterate over all tracks
            for e in tune.tracks[i][1]:     # iterate over events in track
                e.setSource(self.oports[i])     # map track i to output port i
                if e.type!=SND_SEQ_EVENT_TEMPO:
                    e.setSubscribers() # regular events are sent to subscribers
                else:
                    e.setQueueMidiTempoValue(self.q, e.getData().param.value)
                        # tempo change events get their destination from
                        # this convenience method
            self.events.extend(tune.tracks[i][1])   # add track to event list
        self.events.sort(lambda x, y: cmp(x.time.tick, y.time.tick))
                # sort events according to their time stamp

        self.offset=tune.tpq    # compute advance time for playing chunks
        for i in range(len(self.events)-self.chunksize):
            self.offset=min(self.offset,
              self.events[i+self.chunksize].time.tick-self.events[i].time.tick)
        for e in self.events:   # now, schedule events with offset
            e.schedule(self.q, e.time.tick+self.offset)
    def play(self):
        if not self.events: return
        self.q.clear()      
        self.sync()
        self.q.stop()                       # now the queue is empty
        self.echo=snd_seq_event()           # special echo event to trigger
        self.echo.type=SND_SEQ_EVENT_ECHO   # sending chunks of events
        self.echo.setDestination(self.clientID(), self.iport)
                                # echo events gets sent to this sequencer
        self.index=0                    # index of next event to be sent
        self.mt=MidiThread(self)        # start thread listening for incoming
        self.mt.start()                 # events (for catching echo events)
        self.q.start()                  # start q

        self.echo.schedule(self.q, 0)   # send first echo event at time 0
        self.echo.sendAsIs(self)        # to send in first chunk of notes at
                                        # that time

        self.echo.schedule(self.q, self.events[-1].time.tick+2*self.offset)
        self.echo.sendAsIs(self)
            # send another echo event at the end of the piece
            # (time of last event), in order to make sure that
            # the event queue is never while playing this piece
            # (like this, we know that the song is over when
            # the queue is empty
    def callback(self, ev):
        if ev.type==SND_SEQ_EVENT_ECHO:
            # we've received our echo event; it's time to send the
            # next chunk of events

            imax=min(len(self.events), self.index+self.chunksize)
                # the next chunk is self.events[index:imax]

            for i in range(self.index, imax):   # send the next chunk
                self.events[i].sendAsIs(self)
            self.index=imax # and remember the beginning of the next chunk

            if imax<len(self.events): # if we're not done yet...
                self.echo.schedule(self.q,
                         self.events[imax-1].time.tick-self.offset)
                self.echo.sendAsIs(self)
                    # schedule the next echo event at the end of this
                    # chunk to trigger the next chunk
        elif ev.type==SND_SEQ_EVENT_TEMPO:
            self.q.setMidiTempoValue(ev.getData().param.value)
                # set our tempo according to the tempo received
        return 1
    def handleSignal(self, a=None, b=None):
        self.q.stop()
        self.panic()


if __name__ == '__main__':
    def usage():
        sys.stderr.write('usage: %s file.mid' % sys.argv[0])
    if len(sys.argv)!=2:
        usage()
    ps=PlaySeq(MidiToAlsa(sys.argv[1]))
    ps.registerSignalHandler()
    raw_input('hook up ports, hit return')
    ps.play()
    ps.sync()

