"""
pyseq - Python bindings for the ALSA sequencer API

$Id: pyseq.py,v 1.118 2005-08-17 04:14:38+02 brinkman Exp brinkman $
Copyright (c) 2005 Peter Brinkmann (brinkman@math.tu-berlin.de)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation (http://www.gnu.org/copyleft/gpl.html).


Outline

This library is an attempt to create Python bindings for the ALSA
sequencer API in a way that finds a reasonable compromise between
a convenient, high-level API, and the raw power of ALSA. Any task
that requires accurate timing is handled by C routines defined in
pyseq.c, or by ALSA's event queues; none of the actual timing is
done by Python, so that there are no accuracy problems.

The following are the main classes of this package:

snd_seq_event
    A Python shadow class of the ALSA sequencer event struct. I have
    deliberately kept the name of the C struct because this class gives
    access to the full struct, i.e., when dealing with such events in
    Python, you get as much information as you would if you were working
    in C. Many of the C constants for dealing with event structs are also
    included in this library.

    Most of this information is rather low-level, but the snd_seq_event
    class comes with a number of convenience functions, e.g., for creating
    note or control change events, scheduling events, etc., that automate
    standard tasks without the need to understand the actual C struct.

Queue
    A Python wrapper that manages ALSA queues, i.e., devices for scheduling
    events in real time or in terms of MIDI time pulses. The methods of this
    class give access to most features of ALSA queues.

PySeq
    This class ties the entire package together. An instance of PySeq
    manages one instance of an ALSA sequencers as well as its associated
    queues and input/output ports. It also provides a callback method for
    handling incoming MIDI events.

MidiThread
    This class spins off a loop, written in C, that waits for incoming
    MIDI events and sends them to the callback method of an instance of
    PySeq.

Note: When first reading this file, you probably want to skip the first
half or so because it only contains constant definitions...
"""


from ctypes import *
from threading import Thread
import ctutils
import time
import signal
import string

libpyseq=cdll.LoadLibrary(ctutils.findOnPath('_pyseq.so'))

SND_SEQ_ADDRESS_BROADCAST=255
SND_SEQ_CLIENT_SYSTEM=0
SND_SEQ_PORT_SYSTEM_TIMER=0
SND_SEQ_PORT_SYSTEM_ANNOUNCE=1

SND_SEQ_PORT_CAP_READ=(1<<0)       # readable from this port
SND_SEQ_PORT_CAP_WRITE=(1<<1)      # writeable to this port
SND_SEQ_PORT_CAP_DUPLEX=(1<<4)     # allow read/write duplex
SND_SEQ_PORT_CAP_SUBS_READ=(1<<5)  # allow read subscription
SND_SEQ_PORT_CAP_SUBS_WRITE=(1<<6) # allow write subscription

SND_SEQ_PORT_CAPS=\
    SND_SEQ_PORT_CAP_READ | SND_SEQ_PORT_CAP_WRITE | SND_SEQ_PORT_CAP_DUPLEX \
    | SND_SEQ_PORT_CAP_SUBS_READ | SND_SEQ_PORT_CAP_SUBS_WRITE

MidiEvents={}
# system status; event data type = #snd_seq_result_t
MidiEvents[0]='SND_SEQ_EVENT_SYSTEM'
SND_SEQ_EVENT_SYSTEM=0
# returned result status; event data type = #snd_seq_result_t
MidiEvents[1]='SND_SEQ_EVENT_RESULT'
SND_SEQ_EVENT_RESULT=1
# note on and off with duration; event data type = #snd_seq_ev_note_t
MidiEvents[5]='SND_SEQ_EVENT_NOTE'
SND_SEQ_EVENT_NOTE=5
# note on; event data type = #snd_seq_ev_note_t
MidiEvents[6]='SND_SEQ_EVENT_NOTEON'
SND_SEQ_EVENT_NOTEON=6
# note off; event data type = #snd_seq_ev_note_t
MidiEvents[7]='SND_SEQ_EVENT_NOTEOFF'
SND_SEQ_EVENT_NOTEOFF=7
# key pressure change (aftertouch); event data type = #snd_seq_ev_note_t
MidiEvents[8]='SND_SEQ_EVENT_KEYPRESS'
SND_SEQ_EVENT_KEYPRESS=8
# controller; event data type = #snd_seq_ev_ctrl_t
MidiEvents[10]='SND_SEQ_EVENT_CONTROLLER'
SND_SEQ_EVENT_CONTROLLER=10
# program change; event data type = #snd_seq_ev_ctrl_t
MidiEvents[11]='SND_SEQ_EVENT_PGMCHANGE'
SND_SEQ_EVENT_PGMCHANGE=11
# channel pressure; event data type = #snd_seq_ev_ctrl_t
MidiEvents[12]='SND_SEQ_EVENT_CHANPRESS'
SND_SEQ_EVENT_CHANPRESS=12
# pitchwheel; event data type = #snd_seq_ev_ctrl_t; data from -8192 to 8191)
MidiEvents[13]='SND_SEQ_EVENT_PITCHBEND'
SND_SEQ_EVENT_PITCHBEND=13
# 14 bit controller value; event data type = #snd_seq_ev_ctrl_t
MidiEvents[14]='SND_SEQ_EVENT_CONTROL14'
SND_SEQ_EVENT_CONTROL14=14
# 14 bit NRPN;  event data type = #snd_seq_ev_ctrl_t
MidiEvents[15]='SND_SEQ_EVENT_NONREGPARAM'
SND_SEQ_EVENT_NONREGPARAM=15
# 14 bit RPN; event data type = #snd_seq_ev_ctrl_t
MidiEvents[16]='SND_SEQ_EVENT_REGPARAM'
SND_SEQ_EVENT_REGPARAM=16
# [#snd_seq_ev_ctrl_t] = 'SPP with LSB and MSB values; event data type'
MidiEvents[20]='SND_SEQ_EVENT_SONGPOS'
SND_SEQ_EVENT_SONGPOS=20
# [#snd_seq_ev_ctrl_t] = 'Song Select with song ID number; event data type'
MidiEvents[21]='SND_SEQ_EVENT_SONGSEL'
SND_SEQ_EVENT_SONGSEL=21
# midi time code quarter frame; event data type = #snd_seq_ev_ctrl_t
MidiEvents[22]='SND_SEQ_EVENT_QFRAME'
SND_SEQ_EVENT_QFRAME=22
# [#snd_seq_ev_ctrl_t] = 'SMF Time Signature event; event data type'
MidiEvents[23]='SND_SEQ_EVENT_TIMESIGN'
SND_SEQ_EVENT_TIMESIGN=23
# [#snd_seq_ev_ctrl_t] = 'SMF Key Signature event; event data type'
MidiEvents[24]='SND_SEQ_EVENT_KEYSIGN'
SND_SEQ_EVENT_KEYSIGN=24
# MIDI Real Time [#snd_seq_ev_queue_control_t] = 'Start msg; event data type'
MidiEvents[30]='SND_SEQ_EVENT_START'
SND_SEQ_EVENT_START=30
# MIDI Real Time Continue msg; event data type = #snd_seq_ev_queue_control_t
MidiEvents[31]='SND_SEQ_EVENT_CONTINUE'
SND_SEQ_EVENT_CONTINUE=31
# MIDI Real Time [#snd_seq_ev_queue_control_t] = 'Stop msg; event data type'
MidiEvents[32]='SND_SEQ_EVENT_STOP'
SND_SEQ_EVENT_STOP=32
# [#snd_seq_ev_queue_control_t] = 'Set tick queue position; event data type'
MidiEvents[33]='SND_SEQ_EVENT_SETPOS_TICK'
SND_SEQ_EVENT_SETPOS_TICK=33
# [#snd_seq_ev_queue_control_t] = 'Set real-time queue pos; event data type'
MidiEvents[34]='SND_SEQ_EVENT_SETPOS_TIME'
SND_SEQ_EVENT_SETPOS_TIME=34
# ([#snd_seq_ev_queue_control_t] = 'SMF) Tempo event; event data type'
MidiEvents[35]='SND_SEQ_EVENT_TEMPO'
SND_SEQ_EVENT_TEMPO=35
# MIDI Real Time Clock msg; event data type = #snd_seq_ev_queue_control_t
MidiEvents[36]='SND_SEQ_EVENT_CLOCK'
SND_SEQ_EVENT_CLOCK=36
# MIDI Real Time Tick msg; event data type = #snd_seq_ev_queue_control_t
MidiEvents[37]='SND_SEQ_EVENT_TICK'
SND_SEQ_EVENT_TICK=37
# Queue timer skew; event data type = #snd_seq_ev_queue_control_t
MidiEvents[38]='SND_SEQ_EVENT_QUEUE_SKEW'
SND_SEQ_EVENT_QUEUE_SKEW=38
# [#snd_seq_ev_queue_control_t] = 'Sync position changed; event data type'
MidiEvents[39]='SND_SEQ_EVENT_SYNC_POS'
SND_SEQ_EVENT_SYNC_POS=39
# Tune request; event data type = none
MidiEvents[40]='SND_SEQ_EVENT_TUNE_REQUEST'
SND_SEQ_EVENT_TUNE_REQUEST=40
# Reset to power-on state; event data type = none
MidiEvents[41]='SND_SEQ_EVENT_RESET'
SND_SEQ_EVENT_RESET=41
# Active sensing event; event data type = none
MidiEvents[42]='SND_SEQ_EVENT_SENSING'
SND_SEQ_EVENT_SENSING=42
# Echo-back event; event data type = any type
MidiEvents[50]='SND_SEQ_EVENT_ECHO'
SND_SEQ_EVENT_ECHO=50
# OSS emulation raw event; event data type
MidiEvents[51]='SND_SEQ_EVENT_OSS'
SND_SEQ_EVENT_OSS=51
# New client has connected; event data type = #snd_seq_addr_t
MidiEvents[60]='SND_SEQ_EVENT_CLIENT_START'
SND_SEQ_EVENT_CLIENT_START=60
# Client has left the system; event data type = #snd_seq_addr_t
MidiEvents[61]='SND_SEQ_EVENT_CLIENT_EXIT'
SND_SEQ_EVENT_CLIENT_EXIT=61
# Client status/info has changed; event data type = #snd_seq_addr_t
MidiEvents[62]='SND_SEQ_EVENT_CLIENT_CHANGE'
SND_SEQ_EVENT_CLIENT_CHANGE=62
# New port was created; event data type = #snd_seq_addr_t
MidiEvents[63]='SND_SEQ_EVENT_PORT_START'
SND_SEQ_EVENT_PORT_START=63
# Port was deleted from system; event data type = #snd_seq_addr_t
MidiEvents[64]='SND_SEQ_EVENT_PORT_EXIT'
SND_SEQ_EVENT_PORT_EXIT=64
# Port status/info has changed; event data type = #snd_seq_addr_t
MidiEvents[65]='SND_SEQ_EVENT_PORT_CHANGE'
SND_SEQ_EVENT_PORT_CHANGE=65
# Ports connected; event data type = #snd_seq_connect_t
MidiEvents[66]='SND_SEQ_EVENT_PORT_SUBSCRIBED'
SND_SEQ_EVENT_PORT_SUBSCRIBED=66
# Ports disconnected; event data type = #snd_seq_connect_t
MidiEvents[67]='SND_SEQ_EVENT_PORT_UNSUBSCRIBED'
SND_SEQ_EVENT_PORT_UNSUBSCRIBED=67
# [#snd_seq_ev_sample_control_t] = 'Sample select; event data type'
MidiEvents[70]='SND_SEQ_EVENT_SAMPLE'
SND_SEQ_EVENT_SAMPLE=70
# [#snd_seq_ev_sample_control_t] = 'Sample cluster select; event data type'
MidiEvents[71]='SND_SEQ_EVENT_SAMPLE_CLUSTER'
SND_SEQ_EVENT_SAMPLE_CLUSTER=71
# voice start
MidiEvents[72]='SND_SEQ_EVENT_SAMPLE_START'
SND_SEQ_EVENT_SAMPLE_START=72
# voice stop
MidiEvents[73]='SND_SEQ_EVENT_SAMPLE_STOP'
SND_SEQ_EVENT_SAMPLE_STOP=73
# playback frequency
MidiEvents[74]='SND_SEQ_EVENT_SAMPLE_FREQ'
SND_SEQ_EVENT_SAMPLE_FREQ=74
# volume and balance
MidiEvents[75]='SND_SEQ_EVENT_SAMPLE_VOLUME'
SND_SEQ_EVENT_SAMPLE_VOLUME=75
# sample loop
MidiEvents[76]='SND_SEQ_EVENT_SAMPLE_LOOP'
SND_SEQ_EVENT_SAMPLE_LOOP=76
# sample position
MidiEvents[77]='SND_SEQ_EVENT_SAMPLE_POSITION'
SND_SEQ_EVENT_SAMPLE_POSITION=77
# private (hardware dependent) event
MidiEvents[78]='SND_SEQ_EVENT_SAMPLE_PRIVATE1'
SND_SEQ_EVENT_SAMPLE_PRIVATE1=78
# user-defined event; event data type = any (fixed size)
MidiEvents[90]='SND_SEQ_EVENT_USR0'
SND_SEQ_EVENT_USR0=90
# user-defined event; event data type = any (fixed size)
MidiEvents[91]='SND_SEQ_EVENT_USR1'
SND_SEQ_EVENT_USR1=91
# user-defined event; event data type = any (fixed size)
MidiEvents[92]='SND_SEQ_EVENT_USR2'
SND_SEQ_EVENT_USR2=92
# user-defined event; event data type = any (fixed size)
MidiEvents[93]='SND_SEQ_EVENT_USR3'
SND_SEQ_EVENT_USR3=93
# user-defined event; event data type = any (fixed size)
MidiEvents[94]='SND_SEQ_EVENT_USR4'
SND_SEQ_EVENT_USR4=94
# user-defined event; event data type = any (fixed size)
MidiEvents[95]='SND_SEQ_EVENT_USR5'
SND_SEQ_EVENT_USR5=95
# user-defined event; event data type = any (fixed size)
MidiEvents[96]='SND_SEQ_EVENT_USR6'
SND_SEQ_EVENT_USR6=96
# user-defined event; event data type = any (fixed size)
MidiEvents[97]='SND_SEQ_EVENT_USR7'
SND_SEQ_EVENT_USR7=97
# user-defined event; event data type = any (fixed size)
MidiEvents[98]='SND_SEQ_EVENT_USR8'
SND_SEQ_EVENT_USR8=98
# user-defined event; event data type = any (fixed size)
MidiEvents[99]='SND_SEQ_EVENT_USR9'
SND_SEQ_EVENT_USR9=99
# begin of instrument management
MidiEvents[100]='SND_SEQ_EVENT_INSTR_BEGIN'
SND_SEQ_EVENT_INSTR_BEGIN=100
# end of instrument management
MidiEvents[101]='SND_SEQ_EVENT_INSTR_END'
SND_SEQ_EVENT_INSTR_END=101
# query instrument interface info
MidiEvents[102]='SND_SEQ_EVENT_INSTR_INFO'
SND_SEQ_EVENT_INSTR_INFO=102
# result of instrument interface info
MidiEvents[103]='SND_SEQ_EVENT_INSTR_INFO_RESULT'
SND_SEQ_EVENT_INSTR_INFO_RESULT=103
# query instrument format info
MidiEvents[104]='SND_SEQ_EVENT_INSTR_FINFO'
SND_SEQ_EVENT_INSTR_FINFO=104
# result of instrument format info
MidiEvents[105]='SND_SEQ_EVENT_INSTR_FINFO_RESULT'
SND_SEQ_EVENT_INSTR_FINFO_RESULT=105
# reset instrument instrument memory
MidiEvents[106]='SND_SEQ_EVENT_INSTR_RESET'
SND_SEQ_EVENT_INSTR_RESET=106
# get instrument interface status
MidiEvents[107]='SND_SEQ_EVENT_INSTR_STATUS'
SND_SEQ_EVENT_INSTR_STATUS=107
# result of instrument interface status
MidiEvents[108]='SND_SEQ_EVENT_INSTR_STATUS_RESULT'
SND_SEQ_EVENT_INSTR_STATUS_RESULT=108
# put an instrument to port
MidiEvents[109]='SND_SEQ_EVENT_INSTR_PUT'
SND_SEQ_EVENT_INSTR_PUT=109
# get an instrument from port
MidiEvents[110]='SND_SEQ_EVENT_INSTR_GET'
SND_SEQ_EVENT_INSTR_GET=110
# result of instrument query
MidiEvents[111]='SND_SEQ_EVENT_INSTR_GET_RESULT'
SND_SEQ_EVENT_INSTR_GET_RESULT=111
# free instrument(s)
MidiEvents[112]='SND_SEQ_EVENT_INSTR_FREE'
SND_SEQ_EVENT_INSTR_FREE=112
# get instrument list
MidiEvents[113]='SND_SEQ_EVENT_INSTR_LIST'
SND_SEQ_EVENT_INSTR_LIST=113
# result of instrument list
MidiEvents[114]='SND_SEQ_EVENT_INSTR_LIST_RESULT'
SND_SEQ_EVENT_INSTR_LIST_RESULT=114
# set cluster parameters
MidiEvents[115]='SND_SEQ_EVENT_INSTR_CLUSTER'
SND_SEQ_EVENT_INSTR_CLUSTER=115
# get cluster parameters
MidiEvents[116]='SND_SEQ_EVENT_INSTR_CLUSTER_GET'
SND_SEQ_EVENT_INSTR_CLUSTER_GET=116
# result of cluster parameters
MidiEvents[117]='SND_SEQ_EVENT_INSTR_CLUSTER_RESULT'
SND_SEQ_EVENT_INSTR_CLUSTER_RESULT=117
# instrument change
MidiEvents[118]='SND_SEQ_EVENT_INSTR_CHANGE'
SND_SEQ_EVENT_INSTR_CHANGE=118
# system exclusive data (variable length);  event data type = #snd_seq_ev_ext_t
MidiEvents[130]='SND_SEQ_EVENT_SYSEX'
SND_SEQ_EVENT_SYSEX=130
# error event;  event data type = #snd_seq_ev_ext_t
MidiEvents[131]='SND_SEQ_EVENT_BOUNCE'
SND_SEQ_EVENT_BOUNCE=131
# reserved for user apps;  event data type = #snd_seq_ev_ext_t
MidiEvents[135]='SND_SEQ_EVENT_USR_VAR0'
SND_SEQ_EVENT_USR_VAR0=135
# reserved for user apps; event data type = #snd_seq_ev_ext_t
MidiEvents[136]='SND_SEQ_EVENT_USR_VAR1'
SND_SEQ_EVENT_USR_VAR1=136
# reserved for user apps; event data type = #snd_seq_ev_ext_t
MidiEvents[137]='SND_SEQ_EVENT_USR_VAR2'
SND_SEQ_EVENT_USR_VAR2=137
# reserved for user apps; event data type = #snd_seq_ev_ext_t
MidiEvents[138]='SND_SEQ_EVENT_USR_VAR3'
SND_SEQ_EVENT_USR_VAR3=138
# reserved for user apps; event data type = #snd_seq_ev_ext_t
MidiEvents[139]='SND_SEQ_EVENT_USR_VAR4'
SND_SEQ_EVENT_USR_VAR4=139
# NOP; ignored in any case
MidiEvents[255]='SND_SEQ_EVENT_NONE'
SND_SEQ_EVENT_NONE=255


# Event mode flags
SND_SEQ_TIME_STAMP_TICK = (0<<0)  # timestamp in clock ticks 
SND_SEQ_TIME_STAMP_REAL = (1<<0)  # timestamp in real time 
SND_SEQ_TIME_STAMP_MASK = (1<<0)  # mask for timestamp bits 
SND_SEQ_TIME_MODE_ABS = (0<<1)  # absolute timestamp 
SND_SEQ_TIME_MODE_REL = (1<<1)  # relative to current time 
SND_SEQ_TIME_MODE_MASK = (1<<1)  # mask for time mode bits 
SND_SEQ_EVENT_LENGTH_FIXED = (0<<2)  # fixed event size 
SND_SEQ_EVENT_LENGTH_VARIABLE = (1<<2)  # variable event size 
SND_SEQ_EVENT_LENGTH_VARUSR = (2<<2)
            # ariable event size - user memory space 
SND_SEQ_EVENT_LENGTH_MASK = (3<<2)
            # mask for event length bits 
SND_SEQ_PRIORITY_NORMAL = (0<<4)  # normal priority 
SND_SEQ_PRIORITY_HIGH = (1<<4)
            # event should be processed before others 
SND_SEQ_PRIORITY_MASK = (1<<4)  # mask for priority bits 

# typedef enum snd_seq_stop_mode {
#  SND_SEQ_SAMPLE_STOP_IMMEDIATELY = 0, /**< terminate playing immediately */
#  SND_SEQ_SAMPLE_STOP_VENVELOPE = 1,   /**< finish volume envelope */
#  SND_SEQ_SAMPLE_STOP_LOOP = 2         /**< terminate loop and finish wave */
# } snd_seq_stop_mode_t;
SND_SEQ_SAMPLE_STOP_IMMEDIATELY = 0
SND_SEQ_SAMPLE_STOP_VENVELOPE = 1
SND_SEQ_SAMPLE_STOP_LOOP = 2


# /** Sequencer event address */
class snd_seq_addr(Structure):
    _fields_=[
        ('client',c_ubyte),
        ('port',c_ubyte)
    ]
    def __repr__(self):
        return 'client %d, port %d' % (self.client, self.port)

# /** Connection (subscription) between ports */
class snd_seq_connect(Structure):
    _fields_=[
        ('sender',snd_seq_addr),
        ('dest',snd_seq_addr)
    ]
    def __repr__(self):
        return 'sender (%s), dest (%s)' % (`self.sender`, `self.dest`)

# /** Real-time data record */
class snd_seq_real_time(Structure):
    _fields_=[
        ('tv_sec',c_uint),
        ('tv_nsec',c_uint)
    ]
    def __repr__(self):
        return 'sec %d, nsec %d' % (self.tv_sec, self.tv_nsec)

# typedef unsigned int snd_seq_tick_time_t;
# /** unioned time stamp */
class snd_seq_timestamp(Union):
    _fields_=[
        ('tick',c_uint),
        ('time',snd_seq_real_time)
    ]
    def __repr__(self):
        return 'tick %d, time (%s)' % (self.tick, `self.time`)

# /** Note event */
class snd_seq_ev_note(Structure):
    _fields_=[
        ('channel',c_ubyte),
        ('note',c_ubyte),
        ('velocity',c_ubyte),
        ('off_velocity',c_ubyte),
        ('duration',c_uint)
    ]
    def __repr__(self):
        return 'channel %d, note %d, velocity %d, off_velocity %d, duration %d'\
                % (self.channel, self.note, self.velocity,
                     self.off_velocity,self.duration)

# /** Controller event */
class snd_seq_ev_ctrl(Structure):
    _fields_=[
        ('channel',c_ubyte),
        ('unused',c_ubyte*3),
        ('param',c_uint),
        ('value',c_int)
    ]
    def __repr__(self):
        return 'channel %d, param %d, value %d' % \
                        (self.channel, self.param, self.value)

# /** generic set of bytes (12x8 bit) */
class snd_seq_ev_raw8(Structure):
    _fields_=[
        ('d',c_ubyte*12)
    ]

# /** generic set of integers (3x32 bit) */
class snd_seq_ev_raw32(Structure):
    _fields_=[
        ('d',c_uint*3)
    ]

# /** external stored data */
class snd_seq_ev_ext(Structure):
    _fields_=[
        ('len',c_uint),
        ('ptr',c_void_p)
    ]
# Potential problem: packed...
# } __attribute__((packed)) snd_seq_ev_ext_t;
    def __repr__(self):
        return 'vector %s' % (`self.toList()`)
    def toList(self,tp=c_ubyte):
        return [tp.from_address(self.ptr+i).value for i in range(self.len)]
    def fromList(self,lst,tp=c_ubyte):
        self.len=len(lst)
        self.__vec=(tp*self.len)()  # instance var to prevent garbage collection
        for i in range(self.len): self.__vec[i]=lst[i]
        self.ptr=addressof(self.__vec)

# /** Instrument type */
class snd_seq_instr(Structure):
    _fields_=[
        ('cluster',c_uint),
        ('std',c_uint),
        ('bank',c_ushort),
        ('prg',c_ushort)
    ]
    def __repr__(self):
        return 'cluster %d, std %d, bank %d, prg %d' % \
                (self.cluster, self.std, self.bank, self.prg)

# /** sample number */
class snd_seq_ev_sample(Structure):
    _fields_=[
        ('std',c_uint),
        ('bank',c_ushort),
        ('prg',c_ushort)
    ]
    def __repr__(self):
        return 'std %d, bank %d, prg %d' % (self.std, self.bank, self.prg)

# /** sample cluster */
class snd_seq_ev_cluster(Structure):
    _fields_=[
        ('cluster',c_uint)
    ]
    def __repr__(self):
        return 'cluster %d' % (self.cluster)

# /** sample volume control; if any value is set to -1 == do not change */
class snd_seq_ev_volume(Structure):
    _fields_=[
        ('volume',c_short),
        ('lr',c_short),
        ('fr',c_short),
        ('du',c_short)
    ]
    def __repr__(self):
        return 'volume %d, lr %d, fr %d, du %d' % \
                (self.volume, self.lr, self.fr, self.du)

# /** simple loop redefinition */
class snd_seq_ev_loop(Structure):
    _fields_=[
        ('start',c_uint),
        ('end',c_uint)
    ]
    def __repr__(self):
        return 'start %d, end %d' % (self.start, self.end)

class SCUnion(Union):
    _fields_=[
        ('sample',snd_seq_ev_sample),
        ('cluster',snd_seq_ev_cluster),
        ('position',c_uint),
        ('stop_mode',c_int),# snd_seq_stop_mode_t stop_mode;
        ('frequency',c_int),
        ('volume',snd_seq_ev_volume),
        ('loop',snd_seq_ev_loop),
        ('raw8',c_ubyte*8)
    ]

# /** Sample control events */
class snd_seq_ev_sample_control(Structure):
    _fields_=[
        ('channel',c_ubyte),
        ('unused',c_ubyte*3),
        ('param',SCUnion)
    ]
    def __repr__(self):
        return 'channel %d, param %d' % (self.channel, self.param)

# /** INSTR_BEGIN event */
class snd_seq_ev_instr_begin(Structure):
    _fields_=[
        ('timeout',c_int)
    ]
    def __repr__(self):
        return 'timeout %d' % (self.timeout)

# /** Result events */
class snd_seq_result(Structure):
    _fields_=[
        ('event',c_int),
        ('result',c_int)
    ]
    def __repr__(self):
        return 'event %d, result %d' % (self.event, self.result)

# /** Queue skew values */
class snd_seq_queue_skew(Structure):
    _fields_=[
        ('value',c_uint),
        ('base',c_uint)
    ]
    def __repr__(self):
        return 'value %d, base %d' % (self.value, self.base)

class QCUnion(Union):
    _fields_=[
        ('value',c_int),
        ('time',snd_seq_timestamp),
        ('position',c_uint),
        ('skew',snd_seq_queue_skew),
        ('d32',c_uint*32),
        ('d8',c_ubyte*8)
    ]

# /** queue timer control */
class snd_seq_ev_queue_control(Structure):
    _fields_=[
        ('queue',c_ubyte),
        ('unused',c_ubyte*3),
        ('param',QCUnion)
    ]
    def __repr__(self):
        return 'queue %d, value %d' % (self.queue, self.param.value)

class SEUnion(Union):
    _fields_=[
        ('note',snd_seq_ev_note),
        ('control',snd_seq_ev_ctrl),
        ('raw8',snd_seq_ev_raw8),
        ('raw32',snd_seq_ev_raw32),
        ('ext',snd_seq_ev_ext), # potential trouble due to 'packed' property
        ('queue',snd_seq_ev_queue_control),
        ('time',snd_seq_timestamp),
        ('addr',snd_seq_addr),
        ('connect',snd_seq_connect),
        ('result',snd_seq_result),
        ('instr_begin',snd_seq_ev_instr_begin),
        ('sample',snd_seq_ev_sample_control) # potential trouble due to enum
    ]

#/** Sequencer event */
class snd_seq_event(Structure):
    """A Python shadow class for the ALSA event struct. It gives access
    to the entire struct, which is probably more than one needs in most cases.

    For creating and sending events, one can use the convenience methods of
    this class without knowing anything about the underlying structure.

    Example (long version):
        e=snd_seq_event()
        e.setNoteOn(0, 60, 127)   # ch 0, note 60, velocity 127
        e.setSource(0)            # send from output port 0
        self.setSubscribers()     # address to all subscribers of port 0
        e.schedule(q, 3128)       # schedule to be delivered by queue q,
                                  # at MIDI time pulse 3128
        e.sendAsIs()              # now send to queue for delivery

    Example (short version):
        e=snd_seq_event()
        e.setNoteOn(0, 60, 127)
        e.postToQueue(q, 0, 3128)

    These examples are equivalent; the convenience method postToQueue calls all
    the methods of the long example.


    In order to interpret incoming events, the following fields and methods are
    the most important ones:

    type
        Indicates the type of the event e. The constants of the form
        SND_SEQ_EVENT_* help identify events. For instance, a note on
        event will have e.type==SND_SEQ_EVENT_NOTEON, a control change
        event will have e.type==SND_SEQ_EVENT_CONTROLLER, etc.

    getData()
        Returns the part of the event struct that contains the MIDI data
        of the event.

        For instance, if e.type==SND_SEQ_EVENT_NOTEON, then e.getData()
        will return an object of type snd_seq_ev_note, whose fields are
        the usual MIDI values, i.e., e.getData().channel, e.getData().note,
        and e.getData().velocity.  

        If e.type==SND_SEQ_EVENT_CONTROLLER, then e.getData() is of type
        snd_seq_ev_ctrl, and you can access its contents via
        e.getData().channel, e.getData().param, and e.getData().value.

    source
        An object of type snd_seq_addr indicating the origin of the event;
        source.client gives the client ID of the sender, and source.port
        gives the port the event originated from. For instance, my Edirol
        PCR keyboard shows up with client ID 80 and ports 0, 1, 2.
        In order to find client IDs and ports, you can check the MIDI
        connection window of qjackctl.

    dest
        An object of type snd_seq_addr indicating the destination of the
        event. Since the recipient of an event will know its own client ID,
        so that e.dest.client will yield no new information. If the receiving
        sequencer instance has more than one input port, then one can check
        e.dest.port to find out which of the input ports received the event.
    """
    _fields_=[
        ('type',c_ubyte),
        ('flags',c_ubyte),
        ('tag',c_ubyte),
        ('queue',c_ubyte),
        ('time',snd_seq_timestamp),
        ('source',snd_seq_addr),
        ('dest',snd_seq_addr),
        ('data',SEUnion)
    ]
    def __repr__(self):
        return '%s: flags %d, tag %d, queue %d\n    (%s)' % \
            (MidiEvents[self.type], self.flags, self.tag, self.queue,
                 `self.getData()`)
    def setData(self,data):
        if self.type in [0,1]:
            self.data.result=data
        elif self.type in [5,6,7,8]:
            self.data.note=data
        elif self.type in [10,11,12,13,14,15,16,20,21,22,23,24]:
            self.data.control=data
        elif self.type in [30,31,32,33,34,35,36,37,38,39]:
            self.data.queue=data
        elif self.type in [60,61,62,63,64,65]:
            self.data.addr=data
        elif self.type in [66,67]:
            self.data.connect=data
        elif self.type in [70,71]:
            self.data.sample=data
        elif self.type in [130,131,135,136,137,138,139]:
            self.data.ext=data
        else:
            pass
    def getData(self):
        """returns a Python object containing the MIDI data of the event;
        the type of the result depends on the value of self.type"""
        if self.type in [0,1]:
            return self.data.result
        elif self.type in [5,6,7,8]:
            return self.data.note
        elif self.type in [10,11,12,13,14,15,16,20,21,22,23,24]:
            return self.data.control
        elif self.type in [30,31,32,33,34,35,36,37,38,39]:
            return self.data.queue
        elif self.type in [60,61,62,63,64,65]:
            return self.data.addr
        elif self.type in [66,67]:
            return self.data.connect
        elif self.type in [70,71]:
            return self.data.sample
        elif self.type in [130,131,135,136,137,138,139]:
            return self.data.ext
        else:
            return None
    def clear(self):
        libpyseq.clearEvent(addressof(self))
    def free(self):
        "frees the event; according to ALSA docs, this is deprecated"
        libpyseq.snd_seq_free_event(addressof(self))
    def setPriority(self, hp):
        libpyseq.setPriority(addressof(self), hp)
    def setNote(self, ch, key, vel, dur):
        libpyseq.setNote(addressof(self), ch, key, vel, dur)
    def setNoteOn(self, ch, key, vel):
        """turns self into a note on event; parameters are familiar
        MIDI values"""
        libpyseq.setNoteOn(addressof(self), ch, key, vel)
    def setNoteOff(self, ch, key, vel):
        """turns self into a note off event; parameters are familiar
        MIDI values"""
        libpyseq.setNoteOff(addressof(self), ch, key, vel)
    def setKeyPress(self, ch, key, vel):
        """turns self into an aftertouch event; parameters are familiar
        MIDI values"""
        libpyseq.setKeypress(addressof(self), ch, key, vel)
    def setController(self, ch, ctrl, val):
        """turns self into a control change event; parameters are
        familiar MIDI values"""
        libpyseq.setController(addressof(self), ch, ctrl, val)
    def setPgmChange(self, ch, val):
        """turns self into a patch change event; parameters are familiar
        MIDI values"""
        libpyseq.setPgmchange(addressof(self), ch, val)
    def setPitchBend(self, ch, val):
        """turns self into a pitch bend event; parameters are familiar
        MIDI values, with val ranging from -8192..8191"""
        libpyseq.setPitchbend(addressof(self), ch, val)
    def setChanPress(self, ch, val):
        """turns self into a channel pressure event; parameters are
        familiar MIDI values"""
        libpyseq.setChanpress(addressof(self), ch, val)
    def setSysEx(self, lst, tp=c_ubyte):
        """turns self into a system exclusive message; the parameter lst is
        a list of bytes like [0xf0, 0x7f, 0x7f, 0x04, 0x01, 0x40, 0x7f, 0xf7]"""
        ll=len(lst)
        self.__vec=(tp*ll)()  # instance var to prevent garbage collection
        for i in range(ll): self.__vec[i]=lst[i]
        libpyseq.setSysex(addressof(self), ll, addressof(self.__vec))
    def setQueueStart(self, q):
        libpyseq.setQueueStart(addressof(self), q.qid)
    def setQueueStop(self, q):
        libpyseq.setQueueStop(addressof(self), q.qid)
    def setQueueContinue(self, q):
        libpyseq.setQueueContinue(addressof(self), q.qid)
    def setQueueMidiTempoValue(self, q, tempo):
        """queue control event; parameter q is of type Queue, and tempo is
        a MIDI tempo value measured in microseconds per quarter note.  

        Note that this method sets the destination of the event, so that no
        further addressing is necessary."""
        libpyseq.setQueueTempo(addressof(self), q.qid, tempo)
    def setQueueTempo(self, q, bpm):
        """queue control event; parameter q is of type Queue, and bpm is the
        tempo in beats per minute

        Note that this method sets the destination of the event, so that no
        further addressing is necessary."""
        self.setQueueMidiTempoValue(q, 60000000/bpm)
    def setQueuePos(self, q, tick):
        libpyseq.setQueuePosTick(addressof(self), q.qid, tick)
    def setQueuePosRealTime(self, q, sec, nsec):
        time=snd_seq_real_time()
        time.tv_sec=sec
        time.tv_nsec=nsec
        libpyseq.setQueuePosRealTime(addressof(self), q.qid, addressof(time))
    def setMasterVolume(self, v):
        "turns self into a master volume message"
        self.setSysEx([0xf0, 0x7f, 0x7f, 0x04, 0x01, v&127, v>>7, 0xf7])
    def setSource(self, port):
        "sets the source of the event, i.e., the port to send it from"
        libpyseq.setSource(addressof(self), port)
    def setBroadcast(self):
        libpyseq.setBroadcast(addressof(self))
    def setSubscribers(self):
        "addresses the event to all subscribers of its source port"
        libpyseq.setSubscribers(addressof(self))
    def setDestination(self, client, port):
        "addresses the event to one specific client and port"
        libpyseq.setDestination(addressof(self), client, port)
    def schedule(self, queue, tick, rel=0):
        """schedules the event to be delivered by queue (of type Queue) at time
        tick, measured in MIDI pulses; the flag rel indicates whether tick is
        absolute or relative to the current tick"""
        libpyseq.scheduleTick(addressof(self), queue.qid, rel, tick)
    def scheduleRealTime(self, queue, sec, nsec, rel=0):
        """schedules the event to be delivered by queue (of type Queue) at a
        time measured in seconds and nanoseconds; the flag rel indicates
        whether the time is absolute or relative to the current time"""
        time=snd_seq_real_time()
        time.tv_sec=sec
        time.tv_nsec=nsec
        libpyseq.scheduleRealTime(addressof(self), queue.qid, rel,
                         addressof(time))
    def setDirect(self):
        """sets up the event to be delivered directly, without going through
        a queue"""
        libpyseq.setDirect(addressof(self))
    def sendAsIs(self, seq):
        """sends the event as it is, without changing its source, destination,
        or schedule."""
        if libpyseq.sendAsIs(addressof(self), seq.seqhandle)<0:
            raise RuntimeError, 'unable to send event'
    def sendNow(self, seq, srcport, destclient=-1, destport=0):
        """Convenience method: Sends the event right now, without queues, via a
        given sequencer (of type PySeq) and port (integer handle). If the
        optional destination client and port are omitted, then the event
        will be sent to all subscribers of scrport."""
        self.setDirect()
        self.setSource(srcport)
        if destclient==-2:
            self.setBroadcast()
        elif destclient==-1:
            self.setSubscribers()
        else:
            self.setDestination(destclient, destport)
        self.sendAsIs(seq)
    def postToQueue(self, queue, port, tick, rel=0, destclient=-1, destport=0):
        """Convenience method: Schedule the event to be sent via a queue at
        MIDI pulse tick, from a given port (integer handle). If the optional
        destination client and port are omitted, then the event will be sent
        to all subscribers of scrport."""
        self.schedule(queue, tick, rel)
        self.setSource(port)
        if destclient==-2:
            self.setBroadcast()
        elif destclient==-1:
            self.setSubscribers()
        else:
            self.setDestination(destclient, destport)
        self.sendAsIs(queue.seq)
    def postToQueueRealTime(self, queue, port, sec, nsec, rel=0,
                         destclient=-1, destport=0):
        """Convenience method: Schedule the event to be sent via a queue at
        time (sec, nsec), from a given port (integer handle). If the optional
        destination client and port are omitted, then the event will be sent
        to all subscribers of the source port."""
        self.scheduleRealTime(queue, sec, nsec, rel)
        self.setSource(port)
        if destclient==-2:
            self.setBroadcast()
        elif destclient==-1:
            self.setSubscribers()
        else:
            self.setDestination(destclient, destport)
        self.sendAsIs(queue.seq)


class Queue:
    """A Python class for managing sequencer event queues. Each queue belongs
    to a sequencer instance, and there should only be one queue per sequencer.

    Queues have a tempo and a resolution, measured in MIDI time pulses per
    quarter (ticks per quarter)."""
    def __init__(self, seq, name='queue'):
        "constructor; the parameter seq must be an instance of PySeq."
        self.tpq=None
        seq.queue=self
        self.seq=seq
        self.sid=seq.seqhandle
        self.qid=libpyseq.createQueue(self.sid, name);
        if self.qid<0:
            raise RuntimeError, 'queue creation failed'
    def __del__(self):
        self.clear()
        self.wait()
        self.stop()
        self.delete()
    def wait(self, dt=.01):
        "waits while there are still events in the queue"
        while self.getEvents()>0:
            time.sleep(dt)
    def setTempo(self, bpm, tpq=None):
        """sets the tempo (in beats per minute) and the resolution (in ticks
        per quarter note); note that the resolution parameter must be provided
        when first calling this method, and it should be omitted afterwards
        because the resolution cannot be changed"""
        self.setMidiTempoValue(60000000/bpm, tpq)
    def setMidiTempoValue(self, mtv, tpq=None):
        """sets the tempo (in microseconds per quarter note) and the
        resolution (in ticks per quarter note); note that the resolution
        parameter must be provided when first calling this method, and it
        should be omitted afterwards because the resolution cannot be changed"""
        if not tpq is None:
            if self.tpq is None:
                self.tpq=tpq
            elif tpq!=self.tpq:
                raise RuntimeError, 'ticks per quarter may not be changed'
        if self.tpq is None:
            raise RuntimeError, 'ticks per quarter must be set'
        libpyseq.setTempo(self.sid, self.qid, mtv, self.tpq)
    def getTempo(self):
        "returns the current tempo in beats per minute"
        return 60000000/self.getMidiTempoValue()
    def getMidiTempoValue(self):
        "returns the current tempo in microseconds per quarter note"
        return libpyseq.getTempo(self.sid, self.qid)
    def start(self):
        "starts the queue"
        libpyseq.startQueue(self.sid, self.qid)
    def clear(self):
        """clears the queue; use with caution as clearing note off events may
        result in stuck notes; see also PySeq.panic"""
        libpyseq.clearQueue(self.sid, self.qid)
    def stop(self):
        "stops (pauses) the queue"
        libpyseq.stopQueue(self.sid, self.qid)
    def cont(self):
        "continues the queue"
        libpyseq.continueQueue(self.sid, self.qid)
    def delete(self):
        "deletes the queue"
        libpyseq.deleteQueue(self.sid, self.qid)
    def getTick(self):
        "returns the current queue time in MIDI pulses"
        return libpyseq.getTick(self.sid, self.qid)
    def getTime(self):
        "returns the current queue time in seconds and nanoseconds"
        tt=snd_seq_real_time.from_address(libpyseq.getTime(self.sid, self.qid))
        return tt.tv_sec, tt.tv_nsec
    def getEvents(self):
        "returns the number of events waiting to be delivered"
        return libpyseq.getEvents(self.sid, self.qid)
    def getStatus(self):
        "returns the running status of this queue (true iff running)"
        return libpyseq.getStatus(self.sid, self.qid)


MidiHandler=CFUNCTYPE(c_int, c_int)
class MidiThread(Thread):
    """launches a loop waiting for MIDI events in a separate thread;
    keeps the callback method of an instance of PySeq when a MIDI event
    comes in"""
    def __init__(self, seq, daemon=True):
        Thread.__init__(self)
        self.seq=seq
        self.handler=MidiHandler(seq.callbackwrap)
        self.setDaemon(daemon)
        self.stopped=c_int(0)
    def run(self):
        libpyseq.midiLoop(
                self.seq.seqhandle, self.handler, addressof(self.stopped))
    def stop(self):
        self.stopped.value=1
        self.join()


class PySeq:
    """Python wrapper for the ALSA modular synthesizer, manages queues, ports,
    etc."""
    def __init__(self, name='PySeq', *args):
        self.name=name
        self.seqhandle=libpyseq.openSeq(name)
        self.ins={}
        self.outs={}
        self.init(*args)
    def clientID(self):
        """returns the client ID of this sequencer, i.e., the number under
        which it shows up in qjackctl's MIDI connection window"""
        return libpyseq.clientID(self.seqhandle)
    def __del__(self):
        self.close()
    def close(self):
        libpyseq.snd_seq_close(self.seqhandle)
    def sync(self):
        "waits while there are events waiting to be delivered"
        if libpyseq.syncSeq(self.seqhandle)<0:
            raise RuntimeError, 'sync failed'
    def panic(self, port=None):
        "sends 'all notes off' and 'all sounds off' to given port/all ports"
        if port is None:
            ports=self.outs
        else:
            ports=[port]
        e=snd_seq_event()
        for ch in range(16):
            for p in ports:
                e.setController(ch, 120, 0)
                e.sendNow(self, p)
                e.setController(ch, 121, 0)
                e.sendNow(self, p)
                e.setController(ch, 123, 0)
                e.sendNow(self, p)
    def handleSignal(self, a=None, b=None):
        self.panic()
    def registerSignalHandler(self, sigs=[signal.SIGINT, signal.SIGTERM]):
        """installs a signal handler that to avoid stuck notes when terminated
        by signal"""
        for sig in sigs:
            signal.signal(sig, self.handleSignal)
    def setInputPool(self, pool):
        """sets the size of the input pool, i.e., the max number of events
        that may be waiting to be processed; call this method only once,
        before starting a queue"""
        if libpyseq.setInputPool(self.seqhandle, pool)<0:
            raise RuntimeError, 'setInputPool failed'
    def setOutputPool(self, pool, room=None):
        """sets the size of the input pool, i.e., the max number of events
        that may be waiting to be delivered; call this method only once,
        before starting a queue"""
        if libpyseq.setOutputPool(self.seqhandle, pool)<0:
            raise RuntimeError, 'setOutputPool failed'
        if not room is None:
            if libpyseq.setOutputPoolRoom(self.seqhandle, room)<0:
                raise RuntimeError, 'setOutputPool failed'
    def createInPort(self, name='In', allowSubs=1):
        """creates an input port; the last parameter indicates whether the
        port is supposed to accept subscriptions"""
        if allowSubs: allowSubs=1
        else: allowSubs=0
        mi=libpyseq.createInPort(self.seqhandle, name, allowSubs)
        if mi<0:
            raise RuntimeError, 'createPort failed'
        self.ins[mi]=name
        return mi
    def createOutPort(self, name='Out', allowSubs=1):
        """creates an output port; the last parameter indicates whether the
        port is supposed to accept subscriptions"""
        if allowSubs: allowSubs=1
        else: allowSubs=0
        mo=libpyseq.createOutPort(self.seqhandle, name, allowSubs)
        if mo<0:
            raise RuntimeError, 'createPort failed'
        self.outs[mo]=name
        return mo
    def createInOutPort(self, name='io', allowReadSubs=1, allowWriteSubs=1):
        """creates a port for both input and output; the last two parameters
        indicate whether the port is supposed to accept subscriptions"""
        if allowReadSubs: allowReadSubs=1
        else: allowReadSubs=0
        if allowWriteSubs: allowWriteSubs=1
        else: allowWriteSubs=0
        mio=libpyseq.createInOutPort(self.seqhandle, name, allowReadSubs,
                allowWriteSubs)
        if mio<0:
            raise RuntimeError, 'createPort failed'
        self.ins[mio]=name
        self.outs[mio]=name
        return mio
    def deletePort(self, port):
        "deletes a port"
        if libpyseq.deletePort(self.seqhandle, port)<0:
            raise RuntimeError, 'deletePort failed'
        if port in self.ins.keys():
            del self.ins[port]
        if port in self.outs.keys():
            del self.outs[port]
    def connectFrom(self, myport, srcclient, srcport):
        "connects a source client and port to an input port of this sequencer"
        if libpyseq.connectFrom(self.seqhandle, myport, srcclient, srcport)<0:
            raise RuntimeError, 'connectFrom failed'
    def connectTo(self, myport, destclient, destport):
        """connects a destination client and port to an output port
        of this sequencer"""
        if libpyseq.connectTo(self.seqhandle, myport, destclient, destport)<0:
            raise RuntimeError, 'connectTo failed'
    def disconnectFrom(self, myport, srcclient, srcport):
        if libpyseq.disconnectFrom(self.seqhandle, myport,
                     srcclient, srcport)<0:
            raise RuntimeError, 'disconnectFrom failed'
    def disconnectTo(self, myport, destclient, destport):
        if libpyseq.disconnectTo(self.seqhandle, myport,
                     destclient, destport)<0:
            raise RuntimeError, 'disconnectTo failed'
    def callbackwrap(self, addr):
        "for internal use only"
        return self.callback(snd_seq_event.from_address(addr))
    def init(self, *args):
        "init method called by constructor"
        pass
    def callback(self, ev):
        """callback method for handling MIDI events, to be defined
        by subclasses; must return an integer n with the following
        meaning: if (n & 1)==1, free the event; if (n & 2)==2, stop
        the MIDI thread

        The parameter ev is of type snd_seq_event."""
        raise AttributeError, 'PySeq.callback must be defined by subclasses'


class _midiport(Structure):
    'internal use only'
    _fields_=[
        ('client', c_int),
        ('port', c_int),
        ('caps', c_int),
        ('name', c_char*32)
    ]

class _midiclient(Structure):
    'internal use only'
    _fields_=[
        ('id', c_int),
        ('name', c_char*32)
    ]

class _midiconnect(Structure):
    'internal use only'
    _fields_=[
        ('srcclient', c_int),
        ('srcport', c_int),
        ('destclient', c_int),
        ('destport', c_int)
    ]

class _seqlist(Structure):
    'internal use only'
    _fields_=[
        ('nclients', c_int),
        ('clients', _midiclient*64),
        ('nports', c_int),
        ('ports', _midiport*256),
        ('nconnect', c_int),
        ('connect', _midiconnect*1024)
    ]

def getClients(mask=SND_SEQ_PORT_CAPS):
    """
returns a list consisting of MIDI clients with capabilities specified by
the parameter mask. For instance, SND_SEQ_PORT_CAP_READ will only return
ports that can be read from

The return value is a tuple consisting of a representation of clients and
ports as well as a list of connections.

The list of clients and ports is of the form:
    [
        (
            client id, 
            client name,
            [
               (
                   port number,
                   port name,
                   port capabilities
               ),
               ...
            ]
        ),
        ...
    ]

The list of connections is of the form:
    [
        (srcclient, srcport, destclient, destport),
        ...
    ]
"""
    s=_seqlist()
    res=libpyseq.getClients(addressof(s))
    if res==-1:
        raise RuntimeError, 'unable to find clients'
    elif res==-2:
        raise RuntimeError, 'too many clients'
    elif res==-3:
        raise RuntimeError, 'too many ports'
    elif res==-4:
        raise RuntimeError, 'too many connections'
    cls=[]
    for i in range(s.nclients):
        pts=[]
        cl=s.clients[i].id
        for j in range(s.nports):
            caps=s.ports[j].caps
            if s.ports[j].client==cl and (caps & mask):
                pts.append((s.ports[j].port, s.ports[j].name, caps))
        if pts:
            cls.append((cl, s.clients[i].name, pts))
    con=[]
    for i in range(s.nconnect):
        con.append((s.connect[i].srcclient, s.connect[i].srcport,
                         s.connect[i].destclient, s.connect[i].destport))
    return cls, con

def getClientsStr(mask=SND_SEQ_PORT_CAPS):
    "returns a string representation of the results of getClients"
    cls, con=getClients(mask)
    res=''
    for cl in cls:
        res+='%3d: %s\n' % (cl[0], cl[1])
        for pt in cl[2]:
            res+='     %2d: %s\n' % (pt[0], pt[1])
    res+='\n'
    for cn in con:
        res+='%3d:%d --- %3d:%d\n' % cn
    return res

def getClientsByName(name, pname='', mask=SND_SEQ_PORT_CAPS):
    """
returns a list of clients whose name contains the parameter name,
as well as their ports whose name contains the parameter pname
(not case sensitive; underscores and spaces are treated the same)

The result is of the form
    [ (client id, [port numbers]), ...]
"""
    cls, con=getClients(mask)
    name=string.replace(name.lower(), '_', ' ')
    pname=string.replace(pname.lower(), '_', ' ')
    res=[]
    for id, cname, ports in cls:
        if name in string.replace(cname.lower(), '_', ' '):
            res.append((id, [pt for pt, pn, pc in ports
                            if pname in string.replace(pn.lower(), '_', ' ')]))
    return res


class MidiTee(PySeq):
    def init(self, *args):
        self.p=self.createInOutPort()
    def callback(self, ev):
        print ev                 # display event
        ev.sendNow(self, self.p) # and send it to subscribers of our port
        return 1                 # free event; we're done with it


if __name__=='__main__':
    seq=MidiTee('miditee')      # create an ALSA sequencer
    t=MidiThread(seq)           # create a thread listining for incoming events
    t.start()                   # start the thread
                                # now any incoming events will be printed and
                                # sent on to the output port
    raw_input('connect MIDI ports, press return to finish...\n')
    print 'stopping midi thread...'
    t.stop()
    print 'done'

